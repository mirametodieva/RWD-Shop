jQuery(document).ready(function () {
    jQuery('.toggle-nav1' ).click(function (e) {

        jQuery('.menu-left ul' ).toggleClass('active1');

        e.preventDefault();
    });
  
});

